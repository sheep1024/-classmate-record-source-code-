<?php
$Gender=['<i class="fa fa-mars"></i> 帅哥','<i class="fa fa-venus"></i> 美女','<i class="fa fa-transgender"></i> TS/Other'];