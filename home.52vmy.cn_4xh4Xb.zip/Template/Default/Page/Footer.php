<?php
if(!defined("AdminPHP")) exit('<h1 style="color:red">Bad Reuest!</h1> <hr /> Powered By Xlch-AdminPHP');
?>
		</div>
	</div>
</div>
<?php include(T('_Common/Footer'));?>