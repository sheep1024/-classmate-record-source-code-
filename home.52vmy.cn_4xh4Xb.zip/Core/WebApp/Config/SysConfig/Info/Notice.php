<?php /* 请务必不要改动这一行，否则会有安全隐患！ */ if(!defined('RootDir'))exit('Access Denied'); ?>
<span style="color:#5E5E5E;font-family:&quot;background-color:#FFFFFF;font-size:24px;">Hello!</span><span style="color:#5E5E5E;font-family:&quot;font-size:24px;background-color:#FFFFFF;">&nbsp;</span><span style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;"><span style="font-size:18px;">欢迎您使用&nbsp;</span><strong><span style="font-size:24px;">绵羊同学录</span></strong></span><span style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;"></span>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<br />
</p>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<span><span style="font-size:14px;">本程序开发者：</span><span style="color:#E53333;font-size:14px;">绵羊</span><span style="color:#E53333;font-size:14px;">&nbsp;/ sheep</span><span style="font-size:14px;">(QQ3566903443)(asmin@spda1.cn)</span></span>
</p>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<span><span style="font-size:14px;">本程序策划者：</span><span style="color:#337FE5;font-size:14px;">绵羊</span><span style="font-size:14px;">(QQ3566903443</span></span><span style="font-size:14px;">)(</span><span style="font-size:14px;"><span style="color:#5E5E5E;font-family:&quot;font-size:14px;background-color:#FFFFFF;">asmin@spda1.cn</span></span><span style="font-size:14px;">)</span>
</p>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<span><br />
</span>
</p>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<span style="font-size:14px;">同学录官网：home.52vmy.cn</span>
</p>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<span><br />
</span>
</p>
<p style="color:#5E5E5E;font-family:&quot;font-size:13px;background-color:#FFFFFF;">
	<span style="font-size:14px;">祝您使用愉快。</span>
</p>