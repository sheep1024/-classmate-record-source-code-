<?php /* 请务必不要改动这一行，否则会有安全隐患！ */ if(!defined('RootDir'))exit('Access Denied'); ?>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important; font-size: 18px;">欢迎您使用绵羊同学录！</span> 
	</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"=""><br />
</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><span style="font-size:18px;">在注册之前，</span><span style="font-weight:700;"><span style="font-size:18px;">请您阅读以下注意事项：</span></span></span> 
	</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><span style="font-size:18px;">1.非本班人</span><span style="font-weight:700;"><span style="font-size:18px;">请勿注册</span></span><span style="font-size:18px;">。</span></span> 
</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><span style="font-size:18px;">2.您需要获得</span><span style="font-weight:700;"><span style="font-size:18px;">班级密码</span></span><span style="font-size:18px;">，才能够注册本站账户，请联系网站管理员绵羊（3566903443/xrxmy12138）获取。</span></span> 
	</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><span style="font-size:18px;">3.请您尊重他人，请勿</span><span style="font-weight:700;"><span style="font-size:18px;">发表过激言论、上传淫秽信息、辱骂他人</span></span><span style="font-size:18px;">。</span></span> 
</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><span style="font-size:18px;">4.请您做好</span><span style="font-weight:700;"><span style="font-size:18px;">保密工作</span></span><span style="font-size:18px;">。请勿</span><span style="font-weight:700;"><span style="font-size:18px;">将其他同学的资料发布给站外人员</span></span><span style="font-size:18px;">。</span></span> 
	</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><span style="font-size:18px;">5.不要</span><span style="font-weight:700;"><span style="font-size:18px;">泄露</span></span><span style="font-size:18px;">班级密码。</span></span> 
</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"="">
	<span font-size:16px;"="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; outline: 0px !important; -webkit-tap-highlight-color: rgba(171, 163, 163, 0) !important;"><br />
</span> 
	</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"=""> <span style="font-size:18px;">注册成功后，您将可以进入同学录系统。请您在个人主页完善您的资料以及密保信息。</span> 
</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"=""> <span style="font-size:18px;">您可以在【同学录】查看其他同学的资料以及对他留言，在【相册】查看其他同学上传的照片以及分享你的照片，在【留言板】可以进行留言。</span> 
	</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"=""><br />
</p>
<p style="color:#5E5E5E;font-family:" font-size:13px;background-color:#ffffff;"=""> <span><span><span style="font-size:18px;">感谢您的使用，<a href="http://xmy.52vmy.cn" target="_blank"><u><span style="color:#4C33E5;font-size:24px;"><strong>绵羊数据</strong></span></u></a></span><span style="font-size:18px;">敬上<span style="color:#00D5FF;font-size:24px;"><strong>√</strong></span></span></span></span> 
	</p>