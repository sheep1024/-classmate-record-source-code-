<?php
return <<<FlandreStudio_JSON
[
    "\/assets\/img\/cardbg\/1.png",
    "\/assets\/img\/cardbg\/2.png",
    "\/assets\/img\/cardbg\/3.png",
    "\/assets\/img\/cardbg\/4.png",
    "\/assets\/img\/cardbg\/5.png",
    "\/assets\/img\/cardbg\/6.png",
    "\/assets\/img\/cardbg\/7.png",
    "\/assets\/img\/cardbg\/8.png",
    "\/assets\/img\/cardbg\/9.png"
]
FlandreStudio_JSON;
?>