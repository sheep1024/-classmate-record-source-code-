<?php
return <<<FlandreStudio_JSON
{
    "Ip": "localhost",
    "Port": "3306",
    "Username": "home_52vmy_cn",
    "Password": "shHJD3xnGxJDGdwB",
    "Database": "home_52vmy_cn",
    "QZ": "xlch"
}
FlandreStudio_JSON;
?>