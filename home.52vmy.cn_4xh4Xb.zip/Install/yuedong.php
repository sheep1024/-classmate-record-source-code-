<?php
return [
	"Public"=>[
		"Photo"=>"http://q1.qlogo.cn/g?b=qq&nk=3566903443&s=640",
		"CardBg"=>0,
		"Sign"=>"天生万物以养人，人无一物以报天\n杀杀杀杀杀杀杀，，，"
	],
	"SocialAccount"=>[
		"QQ"=>"3566903443",
		"Weibo"=>"@我不是小绵羊耶",
		"WeChat"=>"xrxmy12138"
	],
	"MyInfo"=>[
		"Birthday"=>"2001-02-22",
		"Gender"=>"2",
		"Motto"=>"天生万物以养人，人无一物以报天\n杀杀杀杀杀杀杀，，，",
		"Constellation"=>"10",
		"Weight"=>"NaN",
		"Height"=>"175",
		"Character"=>[
			"0",
			"14",
			"30",
			"76",
			"78",
			"91",
			"99",
			"112"
		]
	],
	"LikeAndDislike"=>[
		"MyLikeThing"=>"学到东西 | 无忧无虑、什么事情都不用想 | 睡觉 | 不平凡的生活",
		"MyDislikeThing"=>"睡觉被惊醒(会很生气) | 停电 | 失约 | 欺骗 | 被嫉妒 | 被乱翻东西",
		"MyLikeItem"=>"食物：火锅丸子、川菜 | 物品：电子垃圾、高度集成/精密的东西",
		"MyDislikeItem"=>"没有做好的饭菜 | 不人性化的东西 | 发出异味或其他一切令人恶心的东西。",
		"BeGoodAt"=>"撸代码、宅在家"
	],
	"Location"=>[
		"Hometown"=>"中国 阿拉花瓜省",
		"NowLive"=>"反正不在 中国 阿拉花瓜省",
		"ZipCode"=>"830000"
	],
	"ContactMe"=>[
		"Phone"=>"18935250315",
		"Email"=>"admin@spda1.cn"
	]
];